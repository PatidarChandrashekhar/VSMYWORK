﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;


using System.IO;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;



public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (args.Length == 2)
        //{

        //    Transform(args[0], args[1]);


        //}
        //else
        //{

        //    PrintUsage();

        //}
        Transform(@"C:\SHEKHAR\MY\MY WORK\XMLtransformation\sampledoc.xml",@"C:\SHEKHAR\MY\MY WORK\XMLtransformation\sample.xslt");
    }


    public static void Transform(string sXmlPath, string sXslPath)
    {

        try
        {

            //load the Xml doc
            XPathDocument myXPathDoc = new XPathDocument(sXmlPath);

            XslTransform myXslTrans = new XslTransform();

            //load the Xsl 
            myXslTrans.Load(sXslPath);

            //create the output stream
            XmlTextWriter myWriter = new XmlTextWriter
                (@"C:\SHEKHAR\MY\MY WORK\XMLtransformation\result2.html", null);

            //do the actual transform of Xml
            myXslTrans.Transform(myXPathDoc, null, myWriter);

            myWriter.Close();


        }
        catch (Exception e)
        {

           // Console.WriteLine("Exception: {0}", e.ToString());
        }

    }


    public static void PrintUsage()
    {
       // Console.WriteLine
       // ("Usage: XmlTransformUtil.exe <xml path> <xsl path>");
    }
    
}
