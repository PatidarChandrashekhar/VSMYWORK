﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;

/// <summary>
/// Summary description for Names
/// </summary>
public class Names
{
	public Names()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    private string _firstName;
    private string _age;
    public string FirstName
    {
        set { _firstName = value; }
        get { return _firstName; }
    }
    public string Age
    {
        set { _age = value; }
        get { return _age; }
    }
}