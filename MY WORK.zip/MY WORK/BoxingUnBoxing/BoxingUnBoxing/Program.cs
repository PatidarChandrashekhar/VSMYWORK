﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BoxingUnBoxing
{
    class Program
    {
        static void Main(string[] args)
        {

            Int32 x = 5;
            object o = x; // Implicit Boxing
            Console.WriteLine("The object o = {0}", o); 


            Int32 x2 = 15;
            object o2 = x2; // Implicit Boxing
             x2 = (Int32)o2; // Explicit UnBoxing    
             Console.WriteLine("The object x2 = {0}", x2);

             Console.ReadLine();


        }
    }
}
