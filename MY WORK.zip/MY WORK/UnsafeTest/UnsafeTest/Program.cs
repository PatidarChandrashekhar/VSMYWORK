﻿// cs_unsafe_keyword.cs
// compile with: /unsafe
using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UnsafeTest
{
    class Program
    {
        //// Unsafe method: takes pointer to int:
        //unsafe static void SquarePtrParam(int* p)
        //{
        //    *p *= *p;
        //}

        //unsafe static void Main()
        //{
        //    int i = 5;
        //    // Unsafe method: uses address-of operator (&):
        //    SquarePtrParam(&i);
        //    Console.WriteLine(i);
        //}



        static int x = y;
        static int y = 5;

        static void Main()
        {
            Console.WriteLine(Program.x);
            Console.WriteLine(Program.y);

            Program.x = 99;
            Console.WriteLine(Program.x);
            Console.ReadLine();
        }


    }
}
