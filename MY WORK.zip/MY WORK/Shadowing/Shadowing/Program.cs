﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Shadowing
{
    class Program
    {
        static void Main(string[] args)
        {
            A clA = new A();
            B clB = new B();

            Console.WriteLine(clA.Foo()); // output Foo
            Console.WriteLine(clA.Bar()); // output Bar
            Console.WriteLine(clB.Foo()); // output NewFoo
            Console.WriteLine(clB.Bar()); // output OverridenBar

            //now let's cast B to an A class
            Console.WriteLine(((A)clB).Foo()); // output Foo <<<--
            Console.WriteLine(((A)clB).Bar()); // output OverridenBar
            Console.Read();
 

        }

        class A
        {
            public string Foo() { return "Foo"; }
            public virtual string Bar() { return "Bar"; }
        }
        class B : A
        {
            public new string Foo() { return "NewFoo"; }
            public override string Bar() { return "OverridenBar"; }
        }

    }
}
