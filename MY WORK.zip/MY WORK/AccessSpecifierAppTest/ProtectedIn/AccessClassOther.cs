﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


//Different class but inside the same assembly named 'AllAccessSpecifierAssembly'
namespace AllAccessSpecifierAssembly
{
    class AccessClassOther
    {

        //Accesibility of 'protected members'::NO 
        //Accesibility of 'internal members'::YES 
        //Accesibility of 'protected internal' members::YES 
        //TIP 2:This class is NOT in same class ' AccessClass' but in the same assembly 
        //so  only protected is NOT accessible rest all are accessible. 
        //IF you want to access protected then inherit class ' AccessClass'. 

        public void AccessClassOtherFunction()
        {
            //AccessClass.protectedA.FunctionA();
            //ERROR:Accesibility of 'protected'::NO.ONLY WHEN 
            //AccessClassOther:AccessClass i.e. when  AccessClassOther inherits AccessClass.
            AccessClass.internalB.FunctionB();
            AccessClass.protectedinternalC.FunctionC(400);
            Console.WriteLine("Inside AccessClassOtherFunction");
        }

    }
}
