﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//A normal public class which contains all different types of access-modifier 
//classes in the assembly named 'AllAccessSpecifierAssembly'

namespace AllAccessSpecifierAssembly
{
    public class AccessClass
    {
        //protected class protectedA
        protected class protectedA
        {
            public static void FunctionA()
            {
                Console.WriteLine("FunctionA(protected)- Parent class");
            }
        }

        //internal class internalB
        internal class internalB
        {
            public static void FunctionB()
            {
                Console.WriteLine("FunctionB(protected)- Parent class");
            }
        }

        //protected internal class protectedinternalC
        protected internal class protectedinternalC
        {
            public int amt = 200;
            public static void FunctionC(int amt)
            {
                Console.WriteLine("" + amt + "");
            }
        }

        // public class:Tricycle
        public class Tricycle
        {
            // private field:
            public int wheels = 3;
            // protected internal property:
            public int Wheels
            {
                get { return wheels; }
            }
            public static int FunctionTime()
            {
                return 6000;
            }
        }


        //TIP 1:This class is inside the same class 'AccessClass' so everything is accessible 
        //from above.Hurray!! 
        class G
        {
            public static void FunctionG()
            {
                //All methods are easily accessible.Does not consider a modified indeed.
                protectedA.FunctionA();
                internalB.FunctionB();
                protectedinternalC.FunctionC(400);
                Console.WriteLine("Inside FunctionG");
            }
        }
    }



    //Different class but inside the same assembly named 'AllAccessSpecifierAssembly'

    public class Soul_1
    {
        //Accesibility of 'protected members'::NO 
        //Accesibility of 'internal members'::YES 
        //Accesibility of 'protected internal' members::YES 
        //TIP 2:This class is NOT in same class 'Soul' but in the same assembly 
        //so  only protected is NOT accessible rest all are accessible. 
        //IF you want to access protected then inherit class 'Soul'. 

        public void fnSoul_1()
        {
            //Soul.A.fnA();//ERROR:Accesibility of 'protected'::NO.ONLY WHEN 
            //Soul_1:Soul i.e. when  Soul_1 inherits Soul.
            AccessClass.internalB.FunctionB();
            AccessClass.protectedinternalC.FunctionC(400);
            Console.WriteLine("fnSoul_1");
        }

    }

}





