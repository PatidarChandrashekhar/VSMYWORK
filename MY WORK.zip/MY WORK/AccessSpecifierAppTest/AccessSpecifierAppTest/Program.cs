﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AllAccessSpecifierAssembly;


namespace AccessSpecifierAppTest
{
    class Program
    {
        static void Main(string[] args)
        {
            //Base b = new Derived();
            //b.SomeOtherMethod();
            D abc = new D();

            abc.FunctionD();

            //Base b = new Derived();
            //Derived d = new Derived();
            //b.SomeOtherMethod();
            //d.SomeOtherMethod();
            Console.ReadLine();
        }
    }

    public class Base
    {
        public virtual void SomeOtherMethod()
        {
            Console.WriteLine("Base class");
        }
    }

    public class Derived : Base
    {
        public override void SomeOtherMethod()
        {
            Console.WriteLine("Base Derived class");
        }
    }



    class D : AccessClass
    {
        public string FunctionD()
        {
            Console.WriteLine("Inside Base FunctionD");
            protectedA.FunctionA();//YES, becuase this is 'protected'
            //internalB.FunctionB();//ERROR:NO, becuase this is 'internal':TIPS 3:only internal is not accessible. 
            protectedinternalC.FunctionC(700);//YES, becuase this is 'protected internal' 
            Tricycle.FunctionTime();
            return "hi this is testing for access specifiers...!";
           
        }
    }








}
