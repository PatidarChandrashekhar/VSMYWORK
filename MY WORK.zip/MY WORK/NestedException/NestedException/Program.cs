﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NestedException
{
    class Program
    {
        public static void Main()
        {

            try
            {

                // a nested try and catch block
                try
                {

                    int[] myArray = new int[2];
                    Console.WriteLine("Attempting to access an invalid array element");
                    myArray[2] = 1;  // throws the exception

                }
                catch (DivideByZeroException e)
                {

                    // code that handles a DivideByZeroException
                    Console.WriteLine("Handling a DivideByZeroException-INNER");
                    Console.WriteLine("Message = " + e.Message);
                    Console.WriteLine("StackTrace = " + e.StackTrace);

                }
                finally
                {
                    Console.WriteLine("FINALLY INNER");
                }

            }
            catch (IndexOutOfRangeException e)
            {

                // code that handles an IndexOutOfRangeException
                Console.WriteLine("Handling an IndexOutOfRangeException-OUTER");
                Console.WriteLine("Message = " + e.Message);
                Console.WriteLine("StackTrace = " + e.StackTrace);

            }
            finally
            { Console.WriteLine("FINALLY OUTER"); }
            Console.ReadLine();

        }

    }
}
