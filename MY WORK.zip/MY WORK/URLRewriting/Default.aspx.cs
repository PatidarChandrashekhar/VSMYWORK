﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Text.RegularExpressions;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Regex rewrite_regex = new Regex(@"(.+)\/((.+)\.aspx)", RegexOptions.IgnoreCase); 
            HttpContext myContext = HttpContext.Current; 
            //see if we need to rewrite the URL
            Match match_rewrite = rewrite_regex.Match(myContext.Request.Path.ToString());
            if (match_rewrite.Groups[2].Captures[0].ToString() == "Default.aspx")
            {
                myContext.RewritePath("Something.aspx", true);
            }
        }
        catch (Exception ex)
        { }
    }
}

