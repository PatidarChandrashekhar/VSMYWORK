using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Specialized;
using System.Text;
using System.Collections.Generic;


public sealed class ChatManager
{
    static StringCollection chatCollection;
    static List<String> users; 

    private static ChatManager instance = new ChatManager(); 
    
	private ChatManager() { }


    static ChatManager()
    {
        chatCollection = new StringCollection();
        users = new List<string>(); 
    }

    public List<String> GetUsers()
    {
        return users; 
    }

    public static ChatManager GetChatManager()
    {
        return instance; 
    }

    public bool IsUserAlreadyAdded(string username)
    {
        if (users.Contains(username)) return true;
        else return false; 
    }

      public void AddUser(string username)
    {
        if(!IsUserAlreadyAdded(username)) 
        {
            users.Add(username); 
        }
    }

    public void AddText(string userName,string text)
    {       
        chatCollection.Add(FormatMessage(userName,text)); 
    }

    public void AddText(string message)
    {
        chatCollection.Add(message); 
    }

    private string FormatMessage(string userName, string text)
    {
        return String.Format("<b>{0} says:</b> {1}", userName, text); 
    }

    public void ClearChatLog()
    {
        chatCollection.Clear();
        users.Clear(); 
    }

    public string BufferText
    {
        get
        {
            StringBuilder sb = new StringBuilder();

            if (chatCollection != null && chatCollection.Count > 0)
            {
                foreach (string chat in chatCollection)
                {
                    sb.Append(chat);
                    sb.Append("<BR>"); 
                }
            }

            return sb.ToString(); 
        }
    }
}
