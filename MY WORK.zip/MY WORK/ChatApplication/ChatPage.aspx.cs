using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;

public partial class ChatPage : System.Web.UI.Page,ICallbackEventHandler
{
    // singleton pattern to get the chat manager object
    ChatManager chatManager = ChatManager.GetChatManager();     

    protected string bufferText;

    protected void Page_Load(object sender, EventArgs e)           
    {
        if (!Page.IsPostBack)
        {
            SetUserName();  
         
            // puts the message that user has entered the chat room 
            if (chatManager.IsUserAlreadyAdded((string)Session["UserName"]) == false)
            {
                // if user is not already added then add the user 

                chatManager.AddUser((string)Session["UserName"]); 

                // says that user has joined the chat room 
                chatManager.AddText(Session["UserName"] as String + " has joined the room."); 

               
            } 
        }

      
        string sbReference = ClientScript.GetCallbackEventReference(this, "arg", "ReceiveServerData", "context");

        string cbScript = String.Empty;

        // check if the script is already registered or not

        if (!ClientScript.IsClientScriptBlockRegistered("CallServer"))
        {

            cbScript = @" function CallServer(arg,context) { " + sbReference + "}";

            ClientScript.RegisterClientScriptBlock(this.GetType(), "CallServer", cbScript, true);
        }
    }

    private void SetUserName()
    {
        lblMessage.Text = Session["UserName"] as String; 
    }

    // This method is used to add the user to the chat
    private void AddUser()
    {
        chatManager.AddUser( (string) Session["UserName"]);
    }

    public string GetCallbackResult()
    {
        // Add to the collection and then return the collection 
        if (!String.IsNullOrEmpty(bufferText))
        {
            chatManager.AddText( (string) Session["UserName"],bufferText);

        }
        return chatManager.BufferText; 
    }

   
    public void RaiseCallbackEvent(string eventArgument)
    {
        if (!String.IsNullOrEmpty(eventArgument))
        {
            bufferText = eventArgument;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        chatManager.ClearChatLog(); 
    }
}
