﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace DynamicFormValidation.Models
{
    public class Person
    {
        public Person()
        {
            PhoneNumbers = new List<PhoneNumber>()
                                {
                                    new PhoneNumber()
                                };    
        }

        [Required]
        public string Forename { get; set; }

        [Required]
        public string Surname { get; set; }

        public IList<PhoneNumber> PhoneNumbers { get; set; }
    }
}