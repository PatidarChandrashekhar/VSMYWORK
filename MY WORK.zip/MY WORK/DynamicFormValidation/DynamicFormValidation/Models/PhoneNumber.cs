﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace DynamicFormValidation.Models
{
    public class PhoneNumber
    {
        [Required]
        public PhoneType Type { get; set; }

        [Required]
        public string Number { get; set; }
    }
}