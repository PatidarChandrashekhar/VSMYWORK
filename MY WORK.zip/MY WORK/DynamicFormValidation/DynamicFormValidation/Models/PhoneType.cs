﻿namespace DynamicFormValidation.Models
{
    public enum PhoneType
    {
        Home,
        Work,
        Mobile
    }
}