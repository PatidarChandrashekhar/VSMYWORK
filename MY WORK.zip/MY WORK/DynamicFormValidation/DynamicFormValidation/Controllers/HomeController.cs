﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DynamicFormValidation.Models;

namespace DynamicFormValidation.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            var person = new Person();

            return View(person);

        }

        [HttpPost]
        public ActionResult Index(Person person)
        {
            if (!ModelState.IsValid)
            {
                return View(person); 
            }

            return Content("Saved...");
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult GetNewPhone()
        {
            return PartialView("EditorTemplates/PhoneNumber", new PhoneNumber());
        }
    }
}
