﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ClassLibExtMethod;

namespace ExtensionMethod1
{
    public static class XX
    {
        public static void NewMethod(this Class1 ob)
        {
            Console.WriteLine("Hello I m extended method");
        }

        public static void NewMethodTest(this Class1 ob)
        {
            Console.WriteLine("Test Hello I m extended method");
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            Class1 ob = new Class1();
            ob.Display();
            ob.Print();
            Console.WriteLine( ob.Display());
            Console.WriteLine(ob.Print());
            ob.NewMethodTest();
            ob.NewMethod();
            Console.ReadKey();
        }
    }

}
