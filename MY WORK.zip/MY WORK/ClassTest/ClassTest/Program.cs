﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassTest
{
    class Program
    {
        static void Main(string[] args)
        {

            // Instance of OutputClass
            OutputClass outCl = new OutputClass("This is printed by the output class.");

            // Call Output class' method
            outCl.printString(); 
            Console.ReadLine();

        }

        class OutputClass
        {
            string myString;

            // Constructor
            private OutputClass()
            {
              
            }


            // Constructor
            public OutputClass(string inputString)
            {
                myString = inputString;
            }

            // Instance Method
            public void printString()
            {
                Console.WriteLine("{0}", myString);
            }

            // Destructor
            ~OutputClass()
            {
                // Some resource cleanup routines
            }
        }



    }
}
