﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Delegate
{
    class Program
    {
        public delegate int Calculate(int value1, int value2);

        static void Main(string[] args)
        {
            //creating the class which contains the methods
            //that will be assigned to delegate objects
            MyClass mc = new MyClass();
            //creating delegate objects and assigning appropriate methods
            //having the EXACT signature of the delegate
            Calculate add = new Calculate(mc.add);
            Calculate sub = new Calculate(mc.sub);

            //using the delegate objects to call the assigned methods 
            Console.WriteLine("Adding two values: " + add(16, 6));
            Console.WriteLine("Subtracting two values: " + sub(16, 4));

            Console.ReadLine();
        }

        public class MyClass
        {
            //a method, that will be assigned to delegate objects
            //having the EXACT signature of the delegate
            public int add(int value1, int value2)
            {
                return value1 + value2;
            }
            //a method, that will be assigned to delegate objects
            //having the EXACT signature of the delegate
            public int sub(int value1, int value2)
            {
                return value1 - value2;
            }

        }

    }
}
