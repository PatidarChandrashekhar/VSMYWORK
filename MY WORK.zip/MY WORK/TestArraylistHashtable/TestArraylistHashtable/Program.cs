﻿using System;
using System.Collections;
public class SamplesArrayList
{

    public static void Main()
    {


        ArrayList ar = new ArrayList();
        ar.Add(1);
        ar.Add(2);
        ar.Add(3);

        foreach (int str in ar)
        {
            //Console.WriteLine("myAL" + str[str]);
            Console.WriteLine("{0}",str);
        }



        Hashtable hashtable = new Hashtable();
        hashtable[1] = "One";
        hashtable[2] = "Two";
        hashtable[13] = "Thirteen";

        foreach (DictionaryEntry entry in hashtable)
        {
            Console.WriteLine("{0}, {1}", entry.Key, entry.Value);
        }

        Console.ReadLine();


        //// Creates and initializes a new ArrayList.
        //ArrayList myAL = new ArrayList();
        //myAL.Add("Hello");
        //myAL.Add("World");
        //myAL.Add("!");

        //// Displays the properties and values of the ArrayList.
        //Console.WriteLine("myAL");
        //Console.WriteLine("\tCount:    {0}", myAL.Count);
        //Console.WriteLine("\tCapacity: {0}", myAL.Capacity);
        //Console.Write("\tValues:");
        //PrintValues(myAL);
    }

    //public static void PrintValues(IEnumerable myList)
    //{
    //    System.Collections.IEnumerator myEnumerator = myList.GetEnumerator();
    //    while (myEnumerator.MoveNext())
    //        Console.Write("\t{0}", myEnumerator.Current);
    //    Console.WriteLine();
    //    Console.ReadLine();
    //}
}
