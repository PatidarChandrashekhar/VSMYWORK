﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
       string connectionString = "server=192.168.21.86;initial catalog=TRLNEXP_NEW1;user id=tjam;password=swaminarayan;";// ConfigurationSettings.AppSettings.Get("Conn_Scanning");// ConfigurationManager.AppSettings["Conn_Scanning"].ToString();
        //Conn.ConnectionString = ConfigurationSettings.AppSettings.Get("Conn_Scanning");// ConfigurationManager.AppSettings["Conn_Scanning"].ToString();
       string commandString = "select * from batchs";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand cmd = new SqlCommand(commandString, connection);
            connection.Open();
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    //listBox1.Items.Add(reader[0].ToString() + ", " + reader[1].ToString());
                }
            }
        }



    }
}
