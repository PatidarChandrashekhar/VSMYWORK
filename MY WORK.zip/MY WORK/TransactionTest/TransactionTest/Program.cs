﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;


namespace TransactionTest
{
    class Program
    {
        static void Main(string[] args)
        {

           // int messageCount = 5;
           //// Create and open a connection
           //SqlConnection connection = new SqlConnection("Data Source=172.16.24.151;Persist Security Info=True;initial catalog=TNE;user id=sa;password=PMS@4;");
           // connection.Open();

           // // Begin Outer Transaction
           // SqlTransaction transaction = connection.BeginTransaction();

           // SqlTransaction innerTransaction = null;
           // for (int i = 0; i < messageCount; ++i)
           // {
           //     innerTransaction = connection.BeginTransaction();
           //              // Do some stuff here eg execute update query
           //              innerTransaction.Commit();
           // }

           // // Commit outer transaction and close the connection
           // transaction.Commit();
           // connection.Close();




            ////////////////////////////////////

            // create a connection object
            string ConnectionString = "Data Source=172.16.24.151;Persist Security Info=True;initial catalog=TCL;user id=sa;password=PMS@4;";
            SqlTransaction tran = null;
            SqlConnection conn = new SqlConnection(ConnectionString);

            try
            {
                conn.Open();
                tran = conn.BeginTransaction("Transaction1");
                SqlCommand cmd = new SqlCommand("INSERT INTO Customers (CustomerID, ContactName, CompanyName)" + "VALUES (516, 'Tim Howard', 'FireCon')", conn, tran);
                tran.Save("save1");
                cmd.ExecuteNonQuery();


                Console.WriteLine("Tim is in the Data base");
                cmd.CommandText ="INSERT INTO Customers (CustomerID, ContactName, CompanyName)" + "VALUES (517, 'Bob Hope', 'Hollwood')";
                tran.Save("save2");
                cmd.ExecuteNonQuery();


                Console.WriteLine("Bob is in the Database");
                cmd.CommandText = "INSERT INTO Customers(CustomerID, ContactName, CompanyName)" + "Values (518, 'Fred Astaire', 'Hollywood')";
                Console.WriteLine("Fred is in the Database");
                tran.Save("save3");
                cmd.ExecuteNonQuery();


                tran.Rollback("save3");
                tran.Commit();
                Console.WriteLine("Transaction Rolledback, only Tim made it.");
                Console.ReadLine();


            }

            catch (Exception exp)
            {
                if (tran != null)
                    tran.Rollback();
                Console.WriteLine(exp.Message.ToString() +
                "\nTransaction Rolledback, Tim didn't make it.");
            }

            finally
            {
                conn.Close();
            }


            ////////////////////////////////////

        }


      
    }
}
