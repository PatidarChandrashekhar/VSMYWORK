﻿using System;
namespace CleanUp
{
    // Resource management pattern for a base class.
    public class Base : IDisposable
    {
        // Track whether Dispose has been called.
        private bool m_disposed;

        /// <summary>
        /// Implement IDisposable, this method will be called at Dispose time for deterministic 
        /// cleanup.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);

            // Remove the disposed object from the finalization queue, finalizer will not be 
            // called. Both managed and unmanaged resources have been freed so there's no 
            // further requirement to call the finalizer.
            GC.SuppressFinalize(this);
        }

        public void SomeMethod()
        {
            // Optionally throw an exception if object already disposed. It's good practice 
            // but often not implemented in the real world. If implementing a library for 
            // publication though it's certainly worth doing.
            if (m_disposed)
            {
                throw new ObjectDisposedException("Base", "Cannot access a disposed object.");
            }

            // Object is not disposed so go ahead and do some work.
        }

        /// <summary>
        /// Dispose(bool) is called at either dispose (disposing = true) or finalize 
        /// (disposing = false) time.
        /// </summary>
        protected virtual void Dispose(bool disposing)
        {
            // Dispose patterns requires that we should be able to call Dispose repeatedly.
            if (m_disposed)
                return;

            if (disposing)
            {
                // Free managed objects here, we'll only hit this code if called at dispose time. 
                // What's a 'managed' object? Any resource that will be freed up by the .NET runtime. 
                // If a resource won't be freed by the runtime without our intervention then it's 
                // an unmanaged resource.

                // If any fields on this type implement IDisposable, call Dispose() on those 
                // objects here. For example if Base held a DbCommand or a CryptoStream we'd 
                // call Dispose on the references here to enable early cleanup.
            }

            // Free unmanaged objects here, this code will be hit when called at dispose time 
            // or finalize time.

            // Set large fields to null.

            m_disposed = true;
        }

        /// <summary>
        /// Use C# destructor syntax for finalization code.
        /// Destructor will only be called if Dispose() was not called. In the ideal case this 
        /// should not happen. If a class implements IDisposable it's best practice to call 
        /// Dispose on all objects of that type when no longer needed.
        /// </summary>
        ~Base()
        {
            Dispose(false);
        }
    }

    // Resource management pattern for a derived class.
    public class Derived : Base
    {
        // Provide a private disposed field at each level of the class hierarchy. Each level 
        // should independently manage it's own disposal.
        private bool m_disposed;

        protected override void Dispose(bool disposing)
        {
            if (m_disposed)
                return;

            try
            {
                if (disposing)
                {
                    // Free managed objects, we'll only hit this code if called at dispose time.
                    // If any fields on this type implement IDisposable, call Dispose() on those 
                    // objects here.
                }

                // Free unmanaged objects, this code will be hit when called at dispose time or 
                // finalize time.

                // Set large fields to null.

                m_disposed = true;
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        public void SomeOtherMethod()
        {
            // Optionally throw an exception if object already disposed.
            if (m_disposed)
            {
                throw new ObjectDisposedException("Derived", "Cannot access a disposed object.");
            }

            // Object is not disposed so go ahead and do some work.
        }

        // The finalizer and parameterless dispose method are inherited from the base class, 
        // so no need to implement here.
    }

    class Program
    {
        static void Main()
        {
            // Create an object that implements IDisposable by wrapping the instantiation in 
            // a using statement. Once the object goes out of scope at the closing brace the 
            // runtime will call Dispose(). This allows for the dispose code to cleanup the 
            // object and remove it from the finalization queue so the finalizer will not run.
            using (Derived d1 = new Derived())
            {

            }

            // Instantiation is not wrapped in a using statement and Dispose() is not called. 
            // For this object the finalizer in Base will be called, but realise that the 
            // finalizer call is non-deterministic - i.e. you don't know when it will be 
            // called, it'll just happen next time the garbage collector gets round to it - 
            //usually when there's some pressure on memory.
            Derived d2 = new Derived();
        }
    }
}
