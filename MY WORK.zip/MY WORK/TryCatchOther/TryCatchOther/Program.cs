﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TryCatchOther
{
    class Program
    {
        static void Main(string[] args)
        {

            int a, b = 0;
            Console.WriteLine("My program starts");
            try
            {
               // a = 10 / b;
                throw new InvalidOperationException();
            }

            catch (InvalidOperationException e)
            {
                Console.WriteLine(e);
            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine(e);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            finally
            {
                Console.WriteLine("finally");
            }
            Console.WriteLine("Remaining program");
            Console.ReadLine();


        }
    }
}
