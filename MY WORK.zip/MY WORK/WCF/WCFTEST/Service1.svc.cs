﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WCFTEST
{
    // NOTE: If you change the class name "Service1" here, you must also update the reference to "Service1" in Web.config and in the associated .svc file.
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall,ConcurrencyMode = ConcurrencyMode.Multiple)]


    public class Service1 : IService1
    {

        public int Add(int num1, int num2)
        {
            //return num1 + num2;
            //throw new Exception("Error while adding number");
           // throw new FaultException("Error while adding number");


            //Do something
            CustomException ex = new CustomException();
            ex.Title = "Error Funtion:Add()";
            ex.ExceptionMessage = "Error occur while doing add function.";
            ex.InnerException = "Inner exception message from serice";
            ex.StackTrace = "Stack Trace message from service.";
            //throw new FaultException(ex,"Reason: Testing the Fault contract");
            throw new FaultException<CustomException>(ex, "Reason: Testing the Fault contract");



        }


       
       public float NewAdd(float operand1, float operand2)
            {
                return operand1 + operand2;
            }

        public int NewAdd(int operand1, int operand2)
         {
                return operand1 + operand2;
            }





        public Employee GetEmployeeDetails(int empId)
        {

            Employee empDetail = new Employee();

            //Do something to get employee details and assign to 'empDetail' properties

            empDetail.Age = 25;
            empDetail.Designation = "Engineer";
            empDetail.Manager = "Ram";
            empDetail.Name = "shekhar";
            empDetail.Salary = 35000;

            return empDetail;
        }



        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
