﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Net.Security;



namespace WCFTEST
{
    // NOTE: If you change the interface name "IService1" here, you must also update the reference to "IService1" in Web.config.
    [ServiceContract]
    public interface IService1
    {
        [OperationContract()]
        [FaultContract(typeof(CustomException))]
        [TransactionFlow(TransactionFlowOption.Allowed)]

        int Add(int num1, int num2);


        [OperationContract(Name = "AddFloats")]
        float NewAdd(float operand1, float operand2);

        [OperationContract(Name = "AddIntegers")]
        int NewAdd(int operand1, int operand2);





        [OperationContract]
        Employee GetEmployeeDetails(int EmpId);



        [OperationContract]
        string GetData(int value);

        [OperationContract]
        CompositeType GetDataUsingDataContract(CompositeType composite);

        // TODO: Add your service operations here
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }


    [DataContract]
    public class Employee
    {
        private string m_Name;
        private int m_Age;
        private int m_Salary;
        private string m_Designation;
        private string m_Manager;

        [DataMember]
        public string Name
        {
            get { return m_Name; }
            set { m_Name = value; }
        }

        [DataMember]
        public int Age
        {
            get { return m_Age; }
            set { m_Age = value; }
        }

        [DataMember]
        public int Salary
        {
            get { return m_Salary; }
            set { m_Salary = value; }
        }

        [DataMember]
        public string Designation
        {
            get { return m_Designation; }
            set { m_Designation = value; }
        }

        [DataMember]
        public string Manager
        {
            get { return m_Manager; }
            set { m_Manager = value; }
        }

    }

    //[MessageContract]
    //public class Department
    //{
    //    [MessageHeader]
    //    public string DepartmentID;
    //    [MessageHeader]
    //    public string DepartmentName;
    //    [MessageHeader]
    //    public Employees Employee();

    //}

    [MessageContract]
    public class EmployeeDetails
    {
        [MessageHeader(ProtectionLevel = ProtectionLevel.None)]
        public string EmpID;
        [MessageBodyMember(ProtectionLevel = ProtectionLevel.Sign)]
        public string Name;
        [MessageBodyMember(ProtectionLevel = ProtectionLevel.Sign)]
        public string Designation;
        [MessageBodyMember(ProtectionLevel = ProtectionLevel.EncryptAndSign)]
        public int Salary;

    }



    [DataContract()]
    public class CustomException
    {
        [DataMember()]
        public string Title;
        [DataMember()]
        public string ExceptionMessage;
        [DataMember()]
        public string InnerException;
        [DataMember()]
        public string StackTrace;
    }

}
