﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;


namespace WebAppTest
{
    public partial class _Default : System.Web.UI.Page
    {


        protected void Page_Init(object sender, EventArgs e)
        {
            // Add meta description tag 
            HtmlMeta metaDescription = new HtmlMeta();
            metaDescription.Name = "Description";
            metaDescription.Content = "Short, unique and keywords rich page description.";
            Page.Header.Controls.Add(metaDescription);

            // Add meta keywords tag 
            HtmlMeta metaKeywords = new HtmlMeta();
            metaKeywords.Name = "Keywords";
            metaKeywords.Content = "selected,page,keywords";
            Page.Header.Controls.Add(metaKeywords);
        } 

        
        
        
        
        
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                MYService.Service1Client ms = new MYService.Service1Client();
                //Response.Write(ms.Add(2, 5));
                ms.Add(2, 5);
                ms.AddFloats(2,3);
                ms.AddIntegers(5,5);
                //ms.GetEmployeeDetails(23);

                Response.Write(ms.AddIntegers(5, 15));

            }
            catch (FaultException<MYService.CustomException>ex)
            {
                //Process the Exception
                Response.Write(ex.ToString());


               
            }

           

        }
    }
}
