﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;


class sample
{

    static sample()
    {
        Console.WriteLine("static constructor called");

    }

    public static void WriteTime()
    {
        Console.WriteLine("Static method called");

    }

    public static void Main(string[] args)
    {
        sample.WriteTime(); // call 1
        sample aNewSample = new sample(); // call 2
        Console.ReadLine();
    }


}

