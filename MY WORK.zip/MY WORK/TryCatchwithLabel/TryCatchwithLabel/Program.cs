﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TryCatchwithLabel
{
    class Program
    {
        static void Main(string[] args)
        {

            int a, b, c;
            a = 10;
            b = 0;
            try
            {
                goto A;
                c = a + b;
                Console.WriteLine(c);
            }
            catch (Exception e)
            {
                Console.WriteLine("In parent exception Catch" +
             e.Message);
            }
            finally
            {
                Console.WriteLine("In finally block");
            }

        A:
            Console.WriteLine("at goto label");

            Console.Read();

        }
    }
}
