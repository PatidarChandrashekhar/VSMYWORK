﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InterfaceTest
{

    public class MyNameParent
    {
        public void Print()
        {
            Console.WriteLine("MyName Print() method");
        }
    }
    public interface InterfaceA
    {
        void SampleMethod();
        void Print();

    }
    public interface InterfaceB : InterfaceA
    {
        void SampleMethod22();
    }

    public class MyNameDerived : InterfaceA
    {
        public void Print()
        {
            Console.WriteLine("MyName Print() method");
        }

       public void SampleMethod()
        {
            Console.WriteLine("SampleMethod() implemented");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
