﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClassLibExtMethod
{
    public class Class1
    {
        public string Display()
        {
            return ("I m in Display");
        }

        public string Print()
        {
            return ("I m in Print");
        }
    }

}
