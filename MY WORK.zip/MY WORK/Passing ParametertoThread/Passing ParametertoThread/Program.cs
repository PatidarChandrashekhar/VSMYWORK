﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;


namespace Passing_ParametertoThread
{
    class Program
    {
       //static void Run()
       //  {
       //      Console.WriteLine("welcome to the " + Thread.CurrentThread.Name +" world");
       //  }
         
       // static void Main(string[] args)
       //  {
       //      Thread.CurrentThread.Name = "MCN";
       //      Thread website = new Thread(Run);
       //      website.Name = "C#Corner";
       //      website.Start();
       //      Run();
       //      Console.Read();
       //  }


        /////////////////////////////////



        static void display(string message)
        {

            Console.WriteLine(message);
        }
        static void Main(string[] args)
        {
            Thread th = new Thread(() => Console.WriteLine("Hello from th!"));
            th.Start();
            Console.Read();
        }

        //////////////////////////


 

     }
 
}

