﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Collections;


public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Using HashTable 

        Hashtable hs = new Hashtable();
        hs.Add("1", "A");
        hs.Add("2", "B");
        hs.Add("3", "C");
        hs.Add("4", "D");
        hs.Add("5", "E");

        DropDownList1.DataSource = hs;
        DropDownList1.DataTextField = "value";
        DropDownList1.DataValueField = "key";
        DropDownList1.DataBind();

        //Result: The DropDown will show the records in following order 
        //E D A B C 



        //Using Dictionary<K,V> 
        Dictionary<string, string> dt = new Dictionary<string, string>();
        dt.Add("1", "A");
        dt.Add("2", "B");
        dt.Add("3", "C");
        dt.Add("4", "D");
        dt.Add("5", "E");

        DropDownList2.DataSource = dt;
        DropDownList2.DataTextField = "value";
        DropDownList2.DataValueField = "key";
        DropDownList2.DataBind();

        //Result: The DropDown will show the records in following order 
        //A B C D E 

    }
}
