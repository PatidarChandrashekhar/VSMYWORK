﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TryCatch
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                int i = 0 / 1;
            }
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.ToString());
            //}
            finally
            { 


            }

        }
    }
}
