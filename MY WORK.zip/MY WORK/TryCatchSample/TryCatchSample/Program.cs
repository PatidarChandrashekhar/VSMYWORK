﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace TryCatchSample
{
    class Program
    {
        static void ProcessString(string s)
        {
            if (s == null)
            {
                throw new FormatException();
            }
        }


        [Serializable]
        public class MyCustomException : Exception
        {
            public MyCustomException()
                : base() { }

            public MyCustomException(string message)
                : base(message) { }

            public MyCustomException(string format, params object[] args)
                : base(string.Format(format, args)) { }

            public MyCustomException(string message, Exception innerException)
                : base(message, innerException) { }

            public MyCustomException(string format, Exception innerException, params object[] args)
                : base(string.Format(format, args), innerException) { }

            protected MyCustomException(SerializationInfo info, StreamingContext context)
                : base(info, context) { }
        }

        static void Main()
        {
            try
            {
                string s = null;
                throw new MyCustomException();
               // ProcessString(s);
                //int a, b = 0;
                //a = 10 / b;
            }
            // Most specific:

            catch (FormatException e)
            {
                Console.WriteLine("{0} First exception caught.", e);
            }

            catch (ArgumentNullException e)
            {
                Console.WriteLine("{0} First exception caught.", e);
            }
            catch (InvalidCastException e)
            {
                Console.WriteLine("Error passing data to PromoteEmployee method. " + e);
            }

            catch (MyCustomException e)
            {
                Console.WriteLine("Error passing data to PromoteEmployee method. " + e);
            }

            // Least specific:
            catch (Exception e)
            {
                Console.WriteLine("{0} Second exception caught.", e);
            }
            Console.ReadLine();
        }

    }
}
