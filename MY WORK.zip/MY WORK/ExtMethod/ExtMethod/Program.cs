﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;




namespace ExtMethod
{

    public class Maths
    {
        public int Number1 =10; 
        public int Number2=5;
        public int Add()
        {
            return Number1 + Number2;
        }
    }

    public static class MyMathExtension    
    {
        public static int Subtract(this Maths x)        
       {      
            return x.Number1 - x.Number2;        
       }
    }


    class Program
    {
        static void Main(string[] args)
        {

            Maths ob = new Maths();
            //ob.Add();
            //ob.Subtract();
            Console.WriteLine(ob.Add());
            Console.WriteLine(ob.Subtract());
            Console.ReadLine();
        }
    }
}
