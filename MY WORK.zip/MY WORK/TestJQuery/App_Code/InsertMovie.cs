﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;


[ServiceBehavior(IncludeExceptionDetailInFaults = true)]
[ServiceContract(Namespace = "")]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]




public class MovieService
{
    //private MoviesDBEntities _dataContext = new MoviesDBEntities(); 
    [OperationContract]
    public bool Insert(string title, string director)
    {            // Create movie to insert   
        //var movieToInsert = new Movie { Title = title, Director = director }; 
        // Save new movie to DB         
        // _dataContext.AddToMovies(movieToInsert);
        //_dataContext.SaveChanges();             // Return movie (with primary key)
        return true;
    }
}

//public class InsertMovie
//{
//    // Add [WebGet] attribute to use HTTP GET
//    [OperationContract]
//    public void DoWork()
//    {
//        // Add your operation implementation here
//        return;
//    }

//    // Add more operations here and mark them with [OperationContract]
//}
