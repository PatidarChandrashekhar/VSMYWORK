﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class AJAX_getcustomer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string id = Request.QueryString["q"];

            Response.Write("<p>");
            Response.Write("<strong> CustomerID:asas</strong><br />");
            Response.Write("<strong> First Name:gfgfg</strong><br />");
            Response.Write("<strong> Surname:trtrt</strong><br />"); 
            Response.Write("</p>");
            Response.End();

    }
}
