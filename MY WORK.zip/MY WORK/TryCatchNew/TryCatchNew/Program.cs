﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;


namespace TryCatchNew
{
    class Program
    {
        public static void Main()
        {
            try
            {
                int a, b = 0;
                //a = 10 / b;
                throw new InvalidOperationException();
            }
            catch (InvalidOperationException e)
            {
                Console.WriteLine(e);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException();
            }
            
            Console.ReadLine();

        }

    }
}
