﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using System.Xml;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for DisplayProduct
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class DisplayProduct : System.Web.Services.WebService {

    public DisplayProduct () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }



    [WebMethod]
    public XmlDocument ProductSearch(string Name)
    {
        string CT = ConfigurationManager.ConnectionStrings["TempConnectionString"].ConnectionString;
        string xml = "<Products><Product><Name>Not Found</Name></Product></Products>";
        try
        {
            //using (SqlConnection con = new SqlConnection(DB.GetDBConn()))
            //{
                SqlConnection con = new SqlConnection(CT);
                con.Open();
                string query = "Select ID,FirstName from T_Employees FOR XML RAW ('ID'),ROOT ('FirstName'),ELEMENTS";

                SqlCommand cmd = new SqlCommand(query, con);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    xml = dr[0].ToString();
                }
                con.Close();
            //}
        }
        catch (Exception)
        { 
        
        }

        XmlDocument xmlDoc = new XmlDocument();
        xmlDoc.LoadXml(xml);
        return xmlDoc;
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }
    
}

