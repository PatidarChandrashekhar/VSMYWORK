﻿using System;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


public partial class _Default : System.Web.UI.Page
                    , System.Web.UI.ICallbackEventHandler 
{
    string RenderedOutput;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        //Register Client Script for Callback
        ClientScriptManager scriptMgr = Page.ClientScript;
        String cbReference = scriptMgr.GetCallbackEventReference
            (this, "arg", "ReceiveServerData", "");
        String callbackScript = "function CallServer(arg, context) {"
            + cbReference + "; }";
        scriptMgr.RegisterClientScriptBlock(this.GetType(), "CallServer"
            , callbackScript, true);
        if (!Page.IsPostBack)
        {
            //Load Products Data
            this.ddlCategories.Items.Add("Select");
            this.ddlCategories.Items.Add("Autos");
            this.ddlCategories.Items.Add("Electronics");
        }
    }
    public void RaiseCallbackEvent(string eventArgument)
    {
        //split eventArgument parameter to get command name and 
        //then value to perform operation like if command is by 
        //Category then we need to load sub categories and if 
        //command is by subcateogry then we need to load products
        string[] commands = eventArgument.Split(",".ToCharArray());

        //check command
        if (commands[0].Equals("LoadSubCategory"))
        {
            //create sub category control dynamically
            DropDownList ddlSubcategories = new DropDownList();
            switch (commands[1])
            {
                    //populate sub category data on the basis of category
                case "Autos":
                    ddlSubcategories.Items.Add("Cars");
                    ddlSubcategories.Items.Add("Bikes");
                    break;
                case "Electronics":
                    ddlSubcategories.Items.Add("Computers");
                    ddlSubcategories.Items.Add("TV");
                    break;
            }
            
            //set client side event
            ddlSubcategories.Attributes.Add("onchange", "CallSrv(this);");

            //primarily rendered output would come in string builder (sb) object
            //through stringwriter which would get data from htmltextwriter 
            //which would get data from RenderControl method            
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            System.IO.StringWriter sw = new System.IO.StringWriter(sb);
            HtmlTextWriter htw = new HtmlTextWriter(sw);

            //render sub categories dropdownlist
            ddlSubcategories.RenderControl(htw);

            //set prefix command name so at client side we could know which 
            //control to load actually and set rendered string
            this.RenderedOutput = "LoadSubCategory," + sb.ToString();
        }
            //check command
        else if (commands[0].Equals("LoadProducts"))
        {
            //create data table in memory and populate that wid 
            //sample/example data to show on webpage 
            DataTable dtProducts = new DataTable();
            //create columns of data table
            dtProducts.Columns.Add("ProductName");
            dtProducts.Columns.Add("ProductDescription");
            dtProducts.Columns.Add("ProductPrice");
            //declare row to fill up with data
            DataRow drProduct;
            switch (commands[1])
            {
                    //create data in memory (datatable) to populate in gridview
                case "Cars":
                    drProduct = dtProducts.NewRow();
                    drProduct["ProductName"] = "Honda";
                    drProduct["ProductDescription"] = "2000 CC";
                    drProduct["ProductPrice"] = "$1000";
                    dtProducts.Rows.Add(drProduct);
                    drProduct = dtProducts.NewRow();
                    drProduct["ProductName"] = "Toyota";
                    drProduct["ProductDescription"] = "1800 CC";
                    drProduct["ProductPrice"] = "$800";
                    dtProducts.Rows.Add(drProduct);                   
                    break;
                case "Bikes":
                    drProduct = dtProducts.NewRow();
                    drProduct["ProductName"] = "Pak Hero";
                    drProduct["ProductDescription"] = "125 CC";
                    drProduct["ProductPrice"] = "$100";
                    dtProducts.Rows.Add(drProduct);
                    drProduct = dtProducts.NewRow();
                    drProduct["ProductName"] = "Honda";
                    drProduct["ProductDescription"] = "250 CC";
                    drProduct["ProductPrice"] = "$150";
                    dtProducts.Rows.Add(drProduct);
                    break;
                case "Computers":
                    drProduct = dtProducts.NewRow();
                    drProduct["ProductName"] = "Dell";
                    drProduct["ProductDescription"] = "P4 Centrino";
                    drProduct["ProductPrice"] = "$400";
                    dtProducts.Rows.Add(drProduct);
                    drProduct = dtProducts.NewRow();
                    drProduct["ProductName"] = "IBM";
                    drProduct["ProductDescription"] = "P4 Think PAD";
                    drProduct["ProductPrice"] = "$350";
                    dtProducts.Rows.Add(drProduct);
                    break;
                case "TV":
                    drProduct = dtProducts.NewRow();
                    drProduct["ProductName"] = "Sony";
                    drProduct["ProductDescription"] = "Plasma";
                    drProduct["ProductPrice"] = "$600";
                    dtProducts.Rows.Add(drProduct);
                    drProduct = dtProducts.NewRow();
                    drProduct["ProductName"] = "Philips";
                    drProduct["ProductDescription"] = "Projection";
                    drProduct["ProductPrice"] = "$550";
                    dtProducts.Rows.Add(drProduct);
                    break;
            }
            //create gridview to bind with created datable to show output
            GridView grvProducts = new GridView();
            grvProducts.DataSource = dtProducts;
            grvProducts.DataBind();

            //primarily rendered output would come in string builder (sb) object
            //through stringwriter which would get data from htmltextwriter 
            //which would get data from RenderControl method    
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            System.IO.StringWriter sw = new System.IO.StringWriter(sb);
            HtmlTextWriter htw = new HtmlTextWriter(sw);
            
            //render sub categories dropdownlist            
            grvProducts.RenderControl(htw);

            //set prefix command name so at client side we could know which
            // control to load actually and set rendered string
            this.RenderedOutput = "LoadProducts," + sb.ToString();
        }
    }
    /// <summary>
    /// Execute/Fires when RaiseCallbackEvent code runs completely
    /// </summary>
    /// <returns></returns>
    public string GetCallbackResult() 
    {        
        //return rendered string with command name
        return RenderedOutput;
    }



}
