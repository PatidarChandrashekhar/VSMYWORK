﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace AsynchronousNatureofDelegates
{
    //public delegate int MyDelegate(int x);

    //public class MyClass
    //{

    //    //A method to be invoke by the delegate 

    //    public int MyMethod(int x)
    //    {

    //        return x * x;

    //    }

    //}

    //class Program
    //{

    //    static void Main(string[] args)
    //    {

    //        MyClass myClass1 = new MyClass();

    //        MyDelegate del = new MyDelegate(myClass1.MyMethod);



    //        //invoke the method synchronously 

    //        int result = del(5);

    //        //this text will not show till the first operation finish 

    //        Console.WriteLine("Proccessing operation...");

    //        Console.WriteLine("Result is: {0}", result);

    //        Console.ReadLine();

    //    }

    //}

    public delegate int MyDelegate(int x);

    public class MyClass
    {

        //A method to be invoke by the delegate 

        public int MyMethod(int x)
        {

            //simulate a long running proccess 

            Thread.Sleep(3000);

            return x * x;

        }

    }

    class Program
    {

        static void Main(string[] args)
        {

            MyClass myClass1 = new MyClass();

            MyDelegate del = new MyDelegate(myClass1.MyMethod);

            //Invoke our methe in another thread 

            IAsyncResult async = del.BeginInvoke(5, null, null);



            //loop until the method is complete 

            while (!async.IsCompleted)
            {

                Console.WriteLine("Not Completed");

            }

            int result = del.EndInvoke(async);

            Console.WriteLine("Result is: {0}", result);

            Console.ReadLine();

        }

    } 

}
