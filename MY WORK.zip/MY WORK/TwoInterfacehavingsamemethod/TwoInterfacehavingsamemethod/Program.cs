﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TwoInterfacehavingsamemethod
{
    class Program
    {
        static void Main(string[] args)
        {

            SampleClass obj = new SampleClass();
            //obj.Paint();  // Compiler error.

            IControl c = (IControl)obj;
            c.Paint();  // Calls IControl.Paint on SampleClass.

            ISurface s = (ISurface)obj;
            s.Paint(); // Calls ISurface.Paint on SampleClass.

            Console.ReadLine();
        }

        interface IControl
        {
            void Paint();
        }
        interface ISurface
        {
            void Paint();
        }
        public class SampleClass : IControl, ISurface
        {
            void IControl.Paint()
            {
                System.Console.WriteLine("IControl.Paint");
            }
            void ISurface.Paint()
            {
                System.Console.WriteLine("ISurface.Paint");
            }
        }



    }
}