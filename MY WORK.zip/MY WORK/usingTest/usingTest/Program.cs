﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;


namespace usingTest
{
    class Program
    {
        static void Main(string[] args)
        {
            //////Font font1 = new Font("Arial", 10.0f);
            //////try
            //////{
            //////    byte charset = font1.GdiCharSet;
            //////}
            //////finally
            //////{
            //////    if (font1 != null)
            //////        ((IDisposable)font1).Dispose();
            //////}

            ////////////////////

            using (Font font3 = new Font("Arial", 10.0f),
            font4 = new Font("Arial", 10.0f))
            {
                // Use font3 and font4.
            }

        }


    }
}
