﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.IO;

public partial class _Default : System.Web.UI.Page 
{

    private int index = -1;
    public static string IMAGES_FOLDER = @"Pictures/";

    protected void Page_Load(object sender, EventArgs e)
    {

    }


    private void RegisterCallbacks()
    {

        string callbackRef = ClientScript.GetCallbackEventReference(this, "arg", "recieveServerData", "context");
        string script = String.Empty;
        if (!ClientScript.IsClientScriptBlockRegistered("callServer"))
         {
            script = "function callServer(arg,context) { " + callbackRef + "}";
            ClientScript.RegisterClientScriptBlock(this.GetType(), "callServer", script, true);
         }

    }


    public string GetCallbackResult()
    {

        return SlideShowHelper.GetImage(index);

    }



    public void RaiseCallbackEvent(string eventArgument)
    {

        index = Int32.Parse(eventArgument);

    }
    public static string GetImage(int index)
    {

        // You can cache the 

        string[] files = Directory.GetFiles(HttpContext.Current.Server.MapPath(SiteConfiguration.GetImagesFolderPath()));

         if (index > files.Length)

            return "DEC";



        if (index < 0)

            return "INC";



        return CreateImageTags(IMAGES_FOLDER, System.IO.Path.GetFileName(files[index]));

    }

    private static string CreateImageTags(string folderName, string fileName)
    {

        return "<img width=\"300px\" height=\"300px\" src=\"" + folderName + fileName + "\"/>";

    }


}
