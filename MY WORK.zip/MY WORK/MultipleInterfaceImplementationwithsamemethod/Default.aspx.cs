﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{

    public interface IA
    {
        string PrintName();
    }
    public interface IB
    {
        string PrintName();
    }

    public class A : IA, IB
    {
        public A()
        {
        }
        public string PrintName()
        {
            return this.GetType().Name;
        }
    }


    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
