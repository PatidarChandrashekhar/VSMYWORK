﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.Structural_Patterns.Structural_Patterns_Structural_Code
{
    class AdapterStructuralCode
    {
        /// <summary>
        //Defination
        //Convert the interface of a class into another interface clients expect. 
        //Adapter lets classes work together that couldn't otherwise because of incompatible interfaces.

        /// Entry point into console application.
        // The classes and/or objects participating in this pattern are: 

        //•Target   (ChemicalCompound) 
        //◦defines the domain-specific interface that Client uses. 
        //•Adapter   (Compound) 
        //◦adapts the interface Adaptee to the Target interface.
        //•Adaptee   (ChemicalDatabank) 
        //◦defines an existing interface that needs adapting. 
        //•Client   (AdapterApp) 
        //◦collaborates with objects conforming to the Target interface. 
        /// </summary>
        //This structural code demonstrates the Adapter pattern which maps the interface of one class onto 
        //another so that they can work together. These incompatible classes may come from different libraries
        //or frameworks. 


        static void Main1()
        {
            // Create adapter and place a request
            Target target = new Adapter();
            target.Request();
            // Wait for user
            Console.ReadKey();
        }

        /// <summary>
        /// The 'Target' class
        /// </summary>
        class Target
        {
            public virtual void Request()
            {
                Console.WriteLine("Called Target Request()");
            }
        }


        /// <summary>
        /// The 'Adapter' class
        /// </summary>
        class Adapter : Target
        {
            private Adaptee _adaptee = new Adaptee();
            public override void Request()
            {
               // Possibly do some other work
               // and then call SpecificRequest
                _adaptee.SpecificRequest();
            }
        }



        /// <summary>
        /// The 'Adaptee' class
        /// </summary>
        class Adaptee
        {
            public void SpecificRequest()
            {
                Console.WriteLine("Called SpecificRequest()");
            }
        }


    }
}
