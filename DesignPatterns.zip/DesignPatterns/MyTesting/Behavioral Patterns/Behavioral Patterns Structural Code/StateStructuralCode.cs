﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.Behavioral_Patterns.Behavioral_Patterns_Structural_Code
{
    class StateStructuralCode
    {
        /// <summary>
        //Defination
        //Allow an object to alter its behavior when its internal state changes. The object will appear to change its class

        /// Entry point into console application.
        //  The classes and/or objects participating in this pattern are: 

        //•Context  (Account) 
        //◦defines the interface of interest to clients 
        //◦maintains an instance of a ConcreteState subclass that defines the current state.
        //•State  (State) 
        //◦defines an interface for encapsulating the behavior associated with a particular state of the Context.
        //•Concrete State  (RedState, SilverState, GoldState) 
        //◦each subclass implements a behavior associated with a state of Context
        /// </summary>
        //This structural code demonstrates the State pattern which allows an object to behave differently depending on its internal state. The difference in behavior is delegated to objects that represent this state. 


        static void Main1()
        {

            // Setup context in a state

            Context c = new Context(new ConcreteStateA());



            // Issue requests, which toggles state

            c.Request();

            c.Request();

            c.Request();

            c.Request();



            // Wait for user

            Console.ReadKey();

        }

        /// <summary>

        /// The 'State' abstract class

        /// </summary>

        abstract class State
        {

            public abstract void Handle(Context context);

        }



        /// <summary>

        /// A 'ConcreteState' class

        /// </summary>

        class ConcreteStateA : State
        {

            public override void Handle(Context context)
            {

                context.State = new ConcreteStateB();

            }

        }



        /// <summary>

        /// A 'ConcreteState' class

        /// </summary>

        class ConcreteStateB : State
        {

            public override void Handle(Context context)
            {

                context.State = new ConcreteStateA();

            }

        }



        /// <summary>

        /// The 'Context' class

        /// </summary>

        class Context
        {

            private State _state;



            // Constructor

            public Context(State state)
            {

                this.State = state;

            }



            // Gets or sets the state

            public State State
            {

                get { return _state; }

                set
                {

                    _state = value;

                    Console.WriteLine("State: " +

                      _state.GetType().Name);

                }

            }



            public void Request()
            {

                _state.Handle(this);

            }

        }

    }
}
