﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.Creational_Patterns.Creational_Patterns_Structural_Code
{
    class SingletonStructuralCode
    {
        /// <summary>
        // Defination
        //Ensure a class has only one instance and provide a global point of access to it. 

        /// Entry point into console application.
        //The classes and/or objects participating in this pattern are: 

        //•Singleton   (LoadBalancer) 
        //◦defines an Instance operation that lets clients access its unique instance. Instance is a class operation. 
        //◦responsible for creating and maintaining its own unique instance.
        /// </summary>
        //This structural code demonstrates the Singleton pattern which assures only a single instance (the singleton) of the class can be created. 


        static void Main1()
        {
            // Constructor is protected -- cannot use new
            Singleton s1 = Singleton.Instance();
            Singleton s2 = Singleton.Instance();
            // Test for same instance
            if (s1 == s2)
            {
                Console.WriteLine("Objects are the same instance");
            }
            // Wait for user
            Console.ReadKey();
        }

        /// <summary>
        /// The 'Singleton' class
        /// </summary>
        class Singleton
        {
            private static Singleton _instance;
            // Constructor is 'protected'
            protected Singleton()
            {
            }
            public static Singleton Instance()
            {
                // Uses lazy initialization.
                // Note: this is not thread safe.
                if (_instance == null)
                {
                    _instance = new Singleton();
                }
                return _instance;
            }
        }
    }
}
